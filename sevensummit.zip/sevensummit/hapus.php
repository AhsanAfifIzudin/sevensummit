<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM instagram WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);

//hapus gambar
while($instagram=mysqli_fetch_assoc($query)){
    $gambar = $instagram['gambar'];
    unlink('images/' .$gambar);
}

$sql2 = "DELETE FROM instagram WHERE no = '$no' ";
$query2 = mysqli_query($koneksi, $sql2);

if($query) {
    header("location:index.php?hapus=sukses");
}else{
    header("location:index.php?hapus=gagal");
}
?>