<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?login");
}
include "koneksi.php";

$sql = "SELECT*FROM instagram ORDER BY no desc";
$query = mysqli_query($koneksi,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SevenSummit</title>
    <link rel="shortcut icon" href="images/logtit.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <style>
    .geeks {
        width: 395px;
        height: 200px;
        overflow: hidden;
        margin: 0 auto;
    }
      
    .geeks img {
        width: 100%;
        transition: 0.5s all ease-in-out;
    }
      
    .geeks:hover img {
        transform: scale(1.5);
    }
</style>
</head>
<body class = " container" >
<!-- <nav class="navbar bg-primary border-bottom border-body" data-bs-theme="dark"> -->
<nav class="navbar navbar-expand-lg fixed-top" style="background-color:#1A508B;">
  <!-- Navbar content -->

    <div class="container-fluid">
        <img src="images/7.png" alt="Bootstrap" width="150" height="50">
        </a>
        <!-- <h1><i class="fa fa-instagram" style="font-size:40px;"></i>Instragam</h1><br> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        </div>
        <div class="navbar-nav">
        <!-- <button class = "float-end btn btn-primary fa fa-plus-square" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background: none; color:primary; border-radius: 100px;border:none;"></button> -->
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="font-size:25px; background: none; color:primary; border-radius: 100px;border:none;"><i class="btn btn-primary fa fa-plus"></i></button></a>
        <a class="nav-link" href="logout.php"><button class = "float-end btn btn-danger bi bi-box-arrow-right" style="font-size:15px;"></button></a>
        </div>
    </div>
<!-- </nav> -->
    </nav><br><br><br><br>
    <!-- modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel" style = "color: blue;">Seven Summit Indonesia</h1>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" class="p-3 mt-3" enctype="multipart/form-data">
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="gambar" id="" required><br>

        <label class="form-label" for="">Caption</label>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br>
        
        <input class="btn btn-primary" type="submit" value="Simpan" name="tambah">
    </form>
      </div>
    </div>
  </div>
</div>
    
   
    <?php while($instagram = mysqli_fetch_assoc($query)) { ?>


<center>
    <div class="card" style="width: 400px;">
    <div class="geeks">
    <img src="images/<?= $instagram['gambar'] ?>" class="card-img-top" alt="Card image cap" style="width: 390px; height: 300px;">
    </div>
    <div class="card-body card-body-cascade text-center pb-0">
        <p class="card-text text-start" style="font-size:14px"><?=$instagram['lokasi'] ?></p>
        <h5 class="card-title text-start"><?=$instagram['caption'] ?></h5>
        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?=$instagram['no']?>" style="font-size:20px; background: none; color:primary; border-radius: 100px;border:none;"><i class="btn btn-success fa fa-pencil"></i></button>
        <a href="hapus.php?no=<?=$instagram['no']?>" id="tombol-hapus"><i class="btn btn-danger fa fa-trash"  style="font-size:20px;"></i></a>
        <div class=" text-center mt-4">
        </div>
    </div>
    </div><br>
    </center>

    <div class="modal fade" id="exampleModal<?=$instagram['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Seven Summit Indonesia</h1>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $instagram['no'] ?>">
        <input type="hidden" name="gambar_lama" value="<?= $instagram['gambar'] ?>">
        <label for="">Gambar</label><br>
        <input class = "form-control"type="file" name="gambar" id="" value="<?= $instagram['gambar'] ?>" ><br>
        <img src="images/<?= $instagram['gambar'] ?>" width="100" alt="" ><br><br>
        <label for="">Caption</label><br>
        <input class = "form-control" type="text" name="caption" id=""  value="<?= $instagram['caption'] ?>"autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input class = "form-control" type="text" name="lokasi" id=""  value="<?= $instagram['lokasi'] ?>" autocomplete="off"><br><br>
        <input class = "btn btn-primary" type="submit" value="Edit" name="edit">
    </form>
      </div>
    </div>
  </div>
</div>
    <?php } ?>
    </div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        // Menambahkan event click pada tombol "Hapus"
        $("#tombol-hapus").click(function() {
            // Menampilkan pop-up alert SweetAlert
            swal({
                title: "Anda yakin?",
                text: "Data akan dihapus permanen!",
                icon: "warning",
                buttons: ["Batal", "Hapus"],
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    // Jika pengguna mengklik "Hapus", maka lakukan tindakan hapus data di sini
                    swal("Data berhasil dihapus!", {
                        icon: "success",
                    });
                } else {
                    // Jika pengguna mengklik "Batal", tindakan di batalkan
                    swal("Data tidak dihapus.");
                }
            });
        });
    });
</script>
</body>
</html>